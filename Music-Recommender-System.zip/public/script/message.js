function showMessage(message) {

    $("#message").text(message).slideDown().delay(2000).slideUp();
}